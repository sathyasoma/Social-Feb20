

function myfun(){
	
	alert("welcome to javascript");
	
}

document.getElementById("demo").innerHTML="changed the paragraph"